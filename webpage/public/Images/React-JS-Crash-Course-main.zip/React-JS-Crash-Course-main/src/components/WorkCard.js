import "./WorkCardStyles.css";

const WorkCard = (props) => {
  return <div className="project-card"></div>;
};

export default WorkCard;
