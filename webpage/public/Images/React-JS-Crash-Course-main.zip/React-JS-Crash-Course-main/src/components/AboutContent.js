import "./AboutContentStyles.css";

import React from "react";

const AboutContent = () => {
  return <div className="about"></div>;
};

export default AboutContent;
