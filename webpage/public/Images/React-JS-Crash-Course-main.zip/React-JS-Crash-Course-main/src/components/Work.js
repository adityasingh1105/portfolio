import "./WorkCardStyles.css";

import React from "react";

const Work = () => {
  return <div className="work-container"></div>;
};

export default Work;
