import "./HeroImg2Styles.css";

import React, { Component } from "react";

class HeroImg2 extends Component {
  render() {
    return <div className="hero-img"></div>;
  }
}

export default HeroImg2;
