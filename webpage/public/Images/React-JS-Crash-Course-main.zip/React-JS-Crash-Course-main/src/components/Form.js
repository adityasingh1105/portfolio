import "./FormStyles.css";

import React from "react";

const Form = () => {
  return <div className="form"></div>;
};

export default Form;
