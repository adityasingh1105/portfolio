import "./HeroImgStyles.css";

import React from "react";

const HeroImg = () => {
  return <div className="hero"></div>;
};

export default HeroImg;
