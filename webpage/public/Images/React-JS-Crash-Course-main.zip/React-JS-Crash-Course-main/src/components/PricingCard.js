import "./PricingCardStyles.css";

const PricingCard = () => {
  return <div className="pricing"></div>;
};

export default PricingCard;
