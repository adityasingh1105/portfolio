import "./NavbarStyles.css";

const Navbar = () => {
  return <div className=""></div>;
};

export default Navbar;
